<?php

namespace App\Livewire\Team;

use Livewire\Component;

class Nation extends Component
{
    public function render()
    {
        return view('livewire.team.nation');
    }
}
