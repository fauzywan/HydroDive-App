<?php

namespace App\Livewire\Team;

use Livewire\Component;

class School extends Component
{
    public function render()
    {
        return view('livewire.team.school');
    }
}
