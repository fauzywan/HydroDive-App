<?php

namespace App\Livewire\Team;

use Livewire\Component;

class Province extends Component
{
    public function render()
    {
        return view('livewire.team.province');
    }
}
