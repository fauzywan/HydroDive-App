<?php

namespace App\Livewire\Event;

use App\Models\Event;
use App\Models\EventDate;
use Livewire\Component;

class EventHistory extends Component
{
    public $yearSelect;
     public function updatedYearSelect($value)
    {
    }

    public function render()
    {
        $events=[];
      $eventYears  = EventDate::distinct()->pluck('competition_start')->map(function ($date) {
            return \Carbon\Carbon::parse($date)->year;
        })->unique();;
        if(!$eventYears->isEmpty()){
            $this->yearSelect = $eventYears->first();
            $events=Event::whereYear('competition_start',$this->yearSelect)->where('status','!=',0)->get();
        }
        return view('livewire.event.event-history',['eventYears'=>$eventYears,'events'=>$events]);
    }
    public function detailHistory($id)
    {
        return $this->redirect("/history/$this->yearSelect/$id/detail", navigate: true);
    }
}
