<?php

namespace App\Livewire\Event;

use Livewire\Component;

class EventBranchIndex extends Component
{
    public function render()
    {
        return view('livewire.event.event-branch-index');
    }
}
