<?php

namespace App\Livewire\Admin;

use App\Models\Event;
use Flux\Flux;
use Illuminate\Support\Facades\Storage;
use Livewire\Component;

class AdminEventIndex extends Component
{
    public $perpage=5;
    public $poster;
    public $navigations=1;
    public function show($no)
    {
         $this->navActive=$no;

    }
    public $navActive=1;
    public function mount()
    {
         $this->navigations=[
             ["no"=>1,"name"=>"Semua Event"],
             ["no"=>2,"name"=>"Event Saya"],
        ];
        $this->perpage = \App\Models\settings::first()->data_per_page;
    }
    public function showPoster($poster)
    {
        $url='storage/event/poster/';
        Flux::modal("modal-poster")->show();
        if($poster == null || $poster == ''){
            $poster = 'default.jpg';
            $url='storage/';
        }
        $this->poster = asset($url.$poster);
    }
    public function render()
    {
        if($this->navActive==1){

            $events=Event::paginate($this->perpage);
        }else{

            $events=Event::where('club_id',1)->paginate($this->perpage);
        }
        return view('livewire.admin.admin-event-index',[
            'events' => $events
        ]);
    }
}
