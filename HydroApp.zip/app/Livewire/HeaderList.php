<?php

namespace App\Livewire;

use Livewire\Component;

class HeaderList extends Component
{
    public function render()
    {
        return view('livewire.header-list');
    }
}
