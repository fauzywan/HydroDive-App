<?php

namespace App\Livewire\Club;

use App\Models\PaymentGateway;
use Livewire\Component;

class MyBill extends Component
{

    public function render()
    {
        return view('livewire.club.my-bill');
    }
}
