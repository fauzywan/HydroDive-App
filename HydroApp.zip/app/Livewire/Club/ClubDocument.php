<?php

namespace App\Livewire\Club;

use Livewire\Component;

class ClubDocument extends Component
{
    public function render()
    {
        return view('livewire.club.club-document');
    }
}
