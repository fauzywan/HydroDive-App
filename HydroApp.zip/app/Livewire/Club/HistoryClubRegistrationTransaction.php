<?php

namespace App\Livewire\Club;

use Livewire\Component;

class HistoryClubRegistrationTransaction extends Component
{
    public function mount($id)
    {
    }
    public function render()
    {
        return view('livewire.club.history-club-registration-transaction');
    }
}
