<?php

namespace App\Livewire\Athlete\Parent;

use Livewire\Component;

class ParentIndex extends Component
{
    public function render()
    {
        return view('livewire.athlete.parent.parent-index');
    }
}
