<?php

namespace App\Livewire\Athlete;

use Livewire\Component;

class AthleteMigrationIndex extends Component
{
    public function render()
    {
        return view('livewire.athlete.athlete-migration-index');
    }
}
