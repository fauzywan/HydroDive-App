<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class coachLicense extends Model
{
    protected $guarded=[];
}
