<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ClubBranch extends Model
{
    protected $guarded = [];
}
