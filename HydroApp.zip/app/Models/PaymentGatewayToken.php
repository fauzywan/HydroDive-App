<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PaymentGatewayToken extends Model
{
    protected $guarded=[];
}
