<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

<<<<<<<< HEAD:app/Http/Controllers/CityController.php
class CityController extends Controller
========
class ClubBranchController extends Controller
>>>>>>>> 016acd4 (03/05/2025):app/Http/Controllers/ClubBranchController.php
{
    //
}
